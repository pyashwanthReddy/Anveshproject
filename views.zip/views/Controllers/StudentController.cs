﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using StudentStaffApp.Models;
using StudentStaffApp.ViewModels;
using System.Data.Entity;

namespace StudentStaffApp.Controllers
{
    public class StudentController : Controller
    {

        private readonly Training_20Feb_MumbaiEntities db = new Training_20Feb_MumbaiEntities();

        // GET: Student
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult AddStudent()
        {
            return View();
        }

        [HttpPost]
        public ActionResult AddStudent(StudentDetail student)
        {
            if(ModelState.IsValid)
            {
                db.StudentDetails.Add(student);
                db.SaveChanges();
                return Content("<html><head><script>alert('Successfully Registered'); window.location.href = '/Student/AddStudent'</script></head></html>");
            }
            return View();
        }

        public ActionResult StudentDetails()
        {
            var studentDetails = db.StudentDetails.ToList();
            return View(studentDetails);
        }

        [HttpPost]
        public ActionResult StudentDetails(int? studentid)
        {
            var student = db.StudentDetails.Where(a=>a.StudentId == studentid).ToList();
            return View(student);
        }

        public ActionResult DeleteStudentById(int? studentid)
        {
            var student = db.StudentDetails.Find(studentid);
            db.StudentDetails.Remove(student);
            db.SaveChanges();
            return Content("<html><head><script>alert('Successfully Deleted'); window.location.href = '/Student/StudentDetails'</script></head></html>");
        }

        public ActionResult GetStudentById(int? studentid)
        {
            var student = db.StudentDetails.Find(studentid);
            return View(student);
        }

        [HttpPost]
        public ActionResult GetStudentById(StudentDetail student)
        {
            db.Entry(student).State = EntityState.Modified;
            db.SaveChanges();
            return Content("<html><head><script>alert('Successfully Updated'); window.location.href = '/Student/StudentDetails'</script></head></html>");
        }

        [HttpPost]
        public ActionResult GetFeesByYear(string year, string branch)
        {
            var fees = db.FeeStructures.Where(a => a.Branch == branch && a.year == year).SingleOrDefault();
            return Json(new { fees = fees.Amount}, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult GetFeesByBranch(string year, string branch)
        {
            var fees = db.FeeStructures.Where(a => a.Branch == branch && a.year == year).SingleOrDefault();
            return Json(new { fees = fees.Amount }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Fees()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Fees(int? studentid)
        {
            List<StudentFees> studentf = new List<StudentFees>();
            var student = db.StudentDetails.Where(a=>a.StudentId == studentid).Include("Fees").ToList();
            if (student.Count != 0)
            {
                if (student[0].Fees.Count == 0)
                {
                    StudentFees studentFee = new StudentFees()
                    {
                        StudentId = student[0].StudentId,
                        StudentName = student[0].Name,
                        FeesAmount = student[0].feesAmount,
                        BalanceAmount = student[0].feesAmount
                    };
                    studentf.Add(studentFee);
                    return View(studentf);
                }
                var fees = student[0].Fees.ToList();

                StudentFees studentFees = new StudentFees()
                {
                    StudentId = student[0].StudentId,
                    StudentName = student[0].Name,
                    FeesAmount = student[0].feesAmount,
                    BalanceAmount = Convert.ToInt64(fees[0].Balance)
                };
                studentf.Add(studentFees);
                return View(studentf);
            }
            return View(studentf);
        }

        public ActionResult PayFees(StudentFees Fees)
        {
            return View(Fees);
        }
    }
}