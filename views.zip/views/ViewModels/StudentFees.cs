﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace StudentStaffApp.ViewModels
{
    public class StudentFees
    {
        [Key]
        public int StudentId { get; set; }
        public string StudentName { get; set; }
        public Nullable<long> FeesAmount { get; set; }
        public Nullable<long> BalanceAmount { get; set; }
    }
}